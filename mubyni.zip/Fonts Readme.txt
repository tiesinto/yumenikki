RM2k/3 Fonts

Install these 4 font files by copying them to your C:\Windows\Fonts\ folder (or, in Vista/7, right-click and select "Install Font...")

You may need to restart your computer for the changes to take effect.


For some cool RPGs, visit http://rpgmaker.net